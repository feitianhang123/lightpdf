# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['run_app.py'],
    pathex=['/home/greatwall/桌面/lightpdf'],
    binaries=[],
    datas=[('icon.ico', '.'), ('resources', 'resources'), ('/home/greatwall/桌面/lightpdf/.venv-build/lib/python3.8/site-packages/pymupdf', 'pymupdf'), ('/home/greatwall/桌面/lightpdf/.venv-build/lib/python3.8/site-packages/fitz', 'fitz')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['pymupdf', 'fitz', 'tkinter', 'matplotlib', 'PyQt5', 'pandas', 'scipy'],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='lightpdf',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='lightpdf',
)
