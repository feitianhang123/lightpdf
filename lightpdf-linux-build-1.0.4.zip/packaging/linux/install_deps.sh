#!/usr/bin/env bash
# System dependencies for 轻PDF编辑器 on Debian/Kylin.
set -e
sudo apt-get update
sudo apt-get install -y \
  python3 python3-venv python3-pip \
  libgl1 libegl1 libglib2.0-0 \
  libxkbcommon0 libxkbcommon-x11-0 \
  libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-randr0 \
  libxcb-render-util0 libxcb-shape0 libxcb-xinerama0 libxcb-xkb1 \
  libdbus-1-3 libfontconfig1 libfreetype6 libxi6 libsm6 libice6
echo "System dependencies installed."
